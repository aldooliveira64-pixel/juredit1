# JurEdit Hub

Dashboard jurídico pessoal — sem API key, sem servidor, sem custo.

## Deploy no GitHub Pages

1. Crie um repositório no github.com (ex: `juredit`)
2. Faça upload de `index.html` e `README.md`
3. Vá em **Settings → Pages → Branch: main → Save**
4. Acesse: `https://SEU-USUARIO.github.io/juredit`

## Deploy no Netlify (drag & drop)

1. Acesse netlify.com → "Add new site" → "Deploy manually"
2. Arraste a pasta com `index.html` para a área de deploy
3. Pronto — URL gerada automaticamente

## Deploy no Vercel

1. Acesse vercel.com → "Add New Project" → "Import Git Repository"
2. Selecione o repositório com o `index.html`
3. Deploy automático

## O que está incluído

| Função | Descrição |
|---|---|
| Dashboard | Projeto, progresso, capítulos concluídos e pendentes |
| Banco de Citações | Salva citações do JurJurisprudência — persiste entre sessões |
| Banco de Referências | Salva notas ABNT do JurBiblioteca — persiste entre sessões |
| Export .docx | Gera Word completo com capa + sumário + footnotes reais |
| Guia de Ferramentas | Prompts prontos para cada artefato do claude.ai |

## Ferramentas IA (claude.ai Free)

Use os artefatos no claude.ai normalmente:
- JurObra v2 — livros e tratados
- JurPeça v2 — petições, pareceres, contestações com PDF
- JurFinanceiro v1 — bancário e mercado de capitais
- JurBiblioteca v2 — doutrina e ABNT
- JurJurisprudência v2 — STF, STJ, súmulas

Cole os resultados gerados no Hub para organizar e exportar.
